=====
Usage
=====

To use MCMC in a project::

    import mcmc
