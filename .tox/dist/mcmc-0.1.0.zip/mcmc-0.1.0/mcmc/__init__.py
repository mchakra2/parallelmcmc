# -*- coding: utf-8 -*-

__author__ = """Maghesree Chakraborty"""
__email__ = 'mchakra2@ur.rochester.edu'
__version__ = '0.1.0'
from mcmc import *
if __name__ == "__main__":
    f=MarkovChain()
    f.main()

